#include<stdio.h>
#include<string.h>
float conservation(char[], char[]);
int main(){
    char DNA1[100];
    char DNA2[100];
    
    printf("Enter the reference genetic or protein sequence:");
    scanf("%s",DNA1);
    printf("Enter the genetic or protein sequence for testing:");
    scanf("%s",DNA2);
    conservation(DNA1, DNA2);
}
float conservation(char dna1[100], char dna2[100]){
    int len1, len2;
    len1 = strlen(dna1);
    len2 = strlen(dna2);
    printf("Length of the sequences: %d and %d",len1, len2);

    int i, j;
    float match=0;
    if (strlen(dna1)==strlen(dna2)){
        for (i=0;i<strlen(dna1); i++){
            if(dna1[i]!=dna2[i]){
                printf("\nPosition %d: MISMATCH",i+1);
            }
        
            else{
                match++;
                printf("\nPosition %d: MATCH",i+1);
            }
        }
        printf("\nMatches found at positions:");
        for (j=0; j<strlen(dna1);j++){
            if(dna1[j]==dna2[j]){
                printf(" %d", j+1);
            }
        }
    float per;
    per = ((match/len1)*100);
    printf("\nPercentage Conservation:%f",per);
    }
    else{
        printf("\nPlease ensure that the length of the sequences are equal.");
    }

}